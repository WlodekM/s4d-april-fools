import "./switch_switch.js";
import "./switch_break.js";
import "./switch_case.js";
import "./switch_default.js";