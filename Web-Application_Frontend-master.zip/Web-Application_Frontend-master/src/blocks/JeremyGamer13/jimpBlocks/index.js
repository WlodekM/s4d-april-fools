import "./grayscale"
import "./invert"
import "./sepia"
import "./resize"
import "./resizeMethod"
import "./scale"
import "./crop"
import "./quality"
import "./drawtext"
import "./flip"
import "./rotate"
import "./brightNcon"
import "./blitNoCrop"
import "./imgHasTPixels"
//import "./"
import "./imageWidth"
import "./imageHeight"
//I FUCKING HATE REPLIT IM JUST TRYING TO RENAME SOMETHING AND IT DRAGS THE ENTIRE FUCKING FOLDER
import "./quickblur"
import "./slowblur"
//new stuff
import "./dither"
import "./newbasiceffect"
//after 10093207590328 eons of me not updating blocks
import "./mask"
import "./pixelate"
// ok bye its 4 am and also i know i spent 2 hours on 2 blocks alright i was just bored and watching youtube 90% of the time
// yay finally another update
import "./posterize"
import "./opacity"
// omg no way i actually did it V
import "./convolute"
import "./kernels"
// holy shit no way i actually did something productive...
import "./composite"
//amogus
//finally added the thing i said i made so long ago
import "./setpixel"
import "./getpixel"
import "./update2"

// by me gsa :)
import "./get buffer"