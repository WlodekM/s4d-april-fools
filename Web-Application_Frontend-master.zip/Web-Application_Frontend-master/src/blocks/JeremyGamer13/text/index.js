import "./textisboolean"
import "./booleanoftext"
import "./texthasnumbers"
import "./randomletterofstring"