//block inputs
import "./blockinputs/encodedecodetype"
//encode stuffs
import "./encode/mainblock"
import "./encode/hash"
import "./encode/hashequalstring"
import "./encode/encryption"
//jggvgvgvwdqd7ygewfygfewf87gefewfewuiuhiuiuhiuhiuhiuhiuhiuhiuhiuhiuhiuhiuhybguhbwhbeijnokmeoip
//uhbuhbygvygvygvygvygvygvygvygvygvygvygvygvygvygvygvygvygvygvygvygvygvygvubiuyvfwiuyvfe8yg87
import "./grabimghttps"
import "./setcurrentdata"
import "./valueofkey"
import "./filehaskey"
import "./getvaluef-lkey"
import "./getallkeys"
import "./amountofkeys"
import "./keynumber"
import "./keywithvalue"
import "./getallvalues"
import "./foreachkey"
import "./foreachkeyinput"
//blputsusuusuusususuususununun8uh89hj89j89j89j89j89j89j89j89j89j89j89j89j89j89j89j89j89j89j89j89j89j89j89j89j89j