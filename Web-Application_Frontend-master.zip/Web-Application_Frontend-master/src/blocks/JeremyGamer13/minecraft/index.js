import "./getjavaserver"
import "./javamotd"
import "./javaplayers"
import "./javaversionname"
import "./javafavicon"
import "./query"
import "./javadata"
// RCON stuff
import "./rcon"
// bedrock s
import "./bedrock"