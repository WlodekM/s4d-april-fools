import "./reg";
import "./add_options";
import "./new_option";