import "./embed_create";
import "./embed_set_color";
import "./embed_set_author";
import "./embed_set_title";
import "./embed_set_desc";
import "./embed_set_thumbnail";
import "./embed_add_field";
import "./embed_set_image";
import "./embed_set_timestamp";
import "./embed_set_footer";
import "./embed_send";
// redman is cool 😎