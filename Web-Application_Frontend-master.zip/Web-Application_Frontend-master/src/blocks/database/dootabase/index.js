import "./add_data";
import "./delete_all";
import "./delete_data";
import "./get_all_data";
import "./get_data";
import "./has_data";
import "./set_data";
import "./set_db";
import "./subtract_data";

import "./multiply_data";
import "./divide_data";