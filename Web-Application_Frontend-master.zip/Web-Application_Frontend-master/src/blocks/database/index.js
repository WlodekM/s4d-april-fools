import "./create_db";
import "./get_data";
import "./has_data";
import "./get_all_data";
import "./set_data";
import "./delete_data";
import "./push_data";
import "./add_data";
import "./subtract_data";
import "./delete_all";

import "./old_database"
import "./dootabase"
