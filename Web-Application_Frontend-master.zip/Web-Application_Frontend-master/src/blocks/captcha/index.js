import "./create_new_captcha";
import "./captcha_image";
import "./send_image";
import "./captcha_value";