# Security Policy

## Reporting a Vulnerability

Please report any vulnerability in [/security/advisories](https://github.com/scratch-for-discord/Web-Application_Frontend/security/advisories)
